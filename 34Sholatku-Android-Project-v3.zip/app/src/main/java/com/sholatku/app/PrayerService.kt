package com.sholatku.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.util.Calendar

class PrayerService : Service() {

    companion object {
        const val ACT_TICK = "com.sholatku.app.TICK"
        const val ACT_SHOW_DZ = "com.sholatku.app.SHOW_DZ"
        const val ACT_HIDE_DZ = "com.sholatku.app.HIDE_DZ"
        private const val CH_SERVICE = "svc"
        const val ACT_STOP_CALL = "com.sholatku.app.STOP_CALL"
        const val ACT_REPOST_HATI = "com.sholatku.app.REPOST_HATI"
        private const val CH_ALERT = "alert2"
        private const val CH_HATI = "hati2"
        private const val NOTIF_ID = 1
        private const val ALERT_ID = 2
        private const val HATI_ID = 4

        @Volatile
        var instance: PrayerService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var overlay: Overlay
    private lateinit var sound: SoundPlayer
    private val done = HashSet<String>()
    private var doneDay = ""
    private var lastSched = 0L
    private var hatiActive = false
    private var hatiName = ""
    private var hatiIqMs = 0L

    private val ticker = object : Runnable {
        override fun run() {
            try {
                checkEvents()
                if (System.currentTimeMillis() - lastSched > 600000L) scheduleNext()
            } catch (e: Exception) {
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannels()
        val n = serviceNotif("Menunggu waktu sholat berikutnya")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        overlay = Overlay(this)
        sound = SoundPlayer(this)
        overlay.onPlus = { dz(1) }
        overlay.onMinus = { dz(-1) }
        overlay.onCloseDzikir = {
            Store.setDzikirOn(this, false)
            overlay.hideDzikir()
        }
        overlay.onCallClosed = {
            sound.stop()
            cancelVib()
        }
        overlay.onHatiClosed = { closeHati() }
        h.post(ticker)
        scheduleNext()
        if (Store.dzikirOn(this)) showDz()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_SHOW_DZ -> {
                Store.setDzikirOn(this, true)
                showDz()
            }
            ACT_HIDE_DZ -> {
                Store.setDzikirOn(this, false)
                overlay.hideDzikir()
            }
            ACT_STOP_CALL -> stopCall()
            ACT_REPOST_HATI -> if (hatiActive) postHatiNotif()
            ACT_TICK -> {
                holdAwake()
                checkEvents()
                scheduleNext()
            }
            else -> {
                holdAwake()
                checkEvents()
                scheduleNext()
            }
        }
        return START_STICKY
    }

    /** Aplikasi digeser dari daftar terbaru: layanan tetap hidup, alarm berikutnya dipastikan terpasang. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        try { scheduleNext() } catch (e: Exception) { }
        super.onTaskRemoved(rootIntent)
    }

    /** Jaga CPU tetap hidup sebentar agar azan sempat mulai saat layar mati. */
    @Suppress("DEPRECATION")
    private fun holdAwake() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sholatku:tick").acquire(30000L)
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        instance = null
        h.removeCallbacksAndMessages(null)
        try { sound.stop() } catch (e: Exception) { }
        try { overlay.hideAll() } catch (e: Exception) { }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- dipanggil dari JS (Bridge)

    fun onConfigChanged() {
        h.post {
            scheduleNext()
            if (overlay.dzikirShown()) {
                val dz = Store.cfg(this).optJSONObject("dz")
                overlay.updateDzikir(count(), dz?.optInt("tg", 100) ?: 100)
            }
        }
    }

    fun runTest(kind: String, json: String) {
        h.post {
            val s = try { JSONObject(json) } catch (e: Exception) { JSONObject() }
            val pick = s.optString("pick", "")
            when (kind) {
                "azan" -> alert("azan", "TES AZAN", "Ini hanya percobaan", s, pick)
                "iq" -> alert("iq", "TES IQOMAH", "Ini hanya percobaan", s, pick)
                else -> hati("FAJR", System.currentTimeMillis() - 11 * 60000L, s)
            }
        }
    }

    // ---------------------------------------------------------------- dzikir

    private fun count(): Int = Store.count(this).coerceAtLeast(0)

    private fun showDz() {
        if (!Settings.canDrawOverlays(this)) {
            Store.setDzikirOn(this, false)
            return
        }
        val dz = Store.cfg(this).optJSONObject("dz")
        overlay.showDzikir(count(), dz?.optInt("tg", 100) ?: 100, dz?.optString("size", "m") ?: "m")
    }

    private fun dz(d: Int) {
        val dzc = Store.cfg(this).optJSONObject("dz")
        val tg = dzc?.optInt("tg", 100) ?: 100
        val n = Math.max(0, count() + d)
        Store.setCount(this, n)
        overlay.updateDzikir(n, tg)
        if (d > 0) {
            if (dzc?.optBoolean("vib", true) != false) vibrate(30)
            if (dzc?.optBoolean("clk", true) != false) {
                try {
                    (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                        .playSoundEffect(AudioManager.FX_KEY_CLICK, 0.5f)
                } catch (e: Exception) { }
            }
            if (n == tg) vibratePattern(longArrayOf(0, 200, 100, 200))
        }
    }

    // ---------------------------------------------------------------- jadwal

    private fun checkEvents() {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        val dayKey = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.DAY_OF_YEAR)}"
        if (dayKey != doneDay) {
            done.clear()
            doneDay = dayKey
        }
        for (ev in PrayerTimes.events(Store.cfg(this), cal)) {
            val win = if (ev.kind == "a") 180000L else 90000L
            if (now >= ev.whenMs && now < ev.whenMs + win && done.add(ev.id)) {
                fire(ev)
                scheduleNext()
            }
        }
    }

    private fun fire(ev: Ev) {
        val cfg = Store.cfg(this)
        val s = cfg.optJSONObject("s") ?: JSONObject()
        val name = PrayerTimes.NAMES[ev.key] ?: ev.key
        when (ev.kind) {
            "a" -> {
                val a = s.optJSONObject("azan") ?: JSONObject()
                val sp = cfg.optJSONObject("sp")?.optString(ev.key, "") ?: ""
                val pick = if (sp.isNotEmpty()) sp else a.optString("pick", "")
                alert("azan", "AZAN BERKUMANDANG", "Waktu $name · ${PrayerTimes.fmt(ev.minute)}", a, pick)
            }
            "i" -> {
                val i = s.optJSONObject("iq") ?: JSONObject()
                alert("iq", "IQOMAH", "Waktu $name — segera sholat", i, i.optString("pick", ""))
            }
            "h" -> {
                val ht = s.optJSONObject("ht") ?: JSONObject()
                hati(name, ev.whenMs - ev.ht * 60000L, ht)
            }
        }
    }

    /** Azan / iqomah: kartu mengambang + notifikasi layar kunci + suara + getar (sesuai mode). */
    private fun alert(kind: String, title: String, sub: String, s: JSONObject, pick: String) {
        val notif = s.optBoolean("notif", true)
        val off = s.optBoolean("off", false)
        wakeScreen()
        if (notif) {
            postAlertNotif(if (kind == "iq") "i" else "a", title, sub)
            val auto = if (kind == "azan" && !off) 600000L else 60000L
            try {
                overlay.showCall(if (kind == "iq") "i" else "a", title, sub, auto)
            } catch (e: Exception) { }
        }
        if (!off) {
            val vol = s.optDouble("vol", 0.7).toFloat()
            val full = s.optString("mode", "ring") == "full"
            sound.play(kind, pick, vol, full, false) {
                // azan selesai -> kartu ikut hilang (iqomah tetap sampai 60 detik)
                if (kind == "azan") h.post { overlay.hideCall(false) }
            }
        }
        if (s.optBoolean("vib", true)) vibrate(vibMs(s))
    }

    /** Tutup kartu azan/iqomah: hentikan suara, getar, dan notifikasi. */
    fun stopCall() {
        h.post {
            overlay.hideCall(false)
            sound.stop()
            cancelVib()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ALERT_ID)
            AlertActivity.current?.finish()
        }
    }

    /**
     * Hati-hati: tetap menyala sampai ditahan 4 detik. Suara hanya diam bila dimatikan,
     * tetapi tampilan dan notifikasi tetap muncul (juga di layar kunci).
     */
    private fun hati(name: String, iqMs: Long, s: JSONObject) {
        wakeScreen()
        hatiActive = true
        hatiName = name
        hatiIqMs = iqMs
        if (overlay.canDraw()) {
            try { overlay.showHati(name, iqMs) } catch (e: Exception) { }
        }
        postHatiNotif()
        if (!s.optBoolean("off", false)) {
            val vol = s.optDouble("vol", 0.5).toFloat()
            sound.play("ht", s.optString("pick", ""), vol, false, true, null)
        }
        if (s.optBoolean("vib", true)) vibrate(vibMs(s))
    }

    /** Dipanggil setelah ditahan 4 detik (overlay atau layar kunci). */
    fun closeHati() {
        h.post {
            hatiActive = false
            overlay.hideHati(false)
            sound.stop()
            cancelVib()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(HATI_ID)
            AlertActivity.current?.finish()
        }
    }

    private fun scheduleNext() {
        lastSched = System.currentTimeMillis()
        try {
            val cfg = Store.cfg(this)
            val now = System.currentTimeMillis()
            val cal = Calendar.getInstance()
            val tomorrow = cal.clone() as Calendar
            tomorrow.add(Calendar.DAY_OF_YEAR, 1)
            val list = PrayerTimes.events(cfg, cal) + PrayerTimes.events(cfg, tomorrow)
            val next = list.filter { it.whenMs > now + 1000L }.minByOrNull { it.whenMs } ?: return
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                this, 100,
                Intent(this, AlarmReceiver::class.java).setAction(ACT_TICK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val show = PendingIntent.getActivity(
                this, 101, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAlarmClock(AlarmManager.AlarmClockInfo(next.whenMs, show), pi)

            val nextAzan = list.filter { it.kind == "a" && it.whenMs > now }.minByOrNull { it.whenMs }
            if (nextAzan != null) {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(
                    NOTIF_ID,
                    serviceNotif("Berikutnya: ${PrayerTimes.NAMES[nextAzan.key]} ${PrayerTimes.fmt(nextAzan.minute)}")
                )
            }
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------------- util

    private fun vibMs(s: JSONObject): Long = longArrayOf(500L, 1500L, 3000L)[s.optInt("vd", 1).coerceIn(0, 2)]

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun vibratePattern(p: LongArray) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(p, -1))
        } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun cancelVib() {
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "sholatku:screen"
            ).acquire(15000L)
        } catch (e: Exception) { }
    }

    private fun createChannels() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try { nm.deleteNotificationChannel("alert") } catch (e: Exception) { }
        val c1 = NotificationChannel(CH_SERVICE, "As-Shalah aktif", NotificationManager.IMPORTANCE_LOW)
        val c2 = NotificationChannel(CH_ALERT, "Azan & iqomah", NotificationManager.IMPORTANCE_HIGH)
        c2.setSound(null, null)
        c2.enableVibration(false)
        c2.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        val c3 = NotificationChannel(CH_HATI, "Hati-hati", NotificationManager.IMPORTANCE_HIGH)
        c3.setSound(null, null)
        c3.enableVibration(false)
        c3.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(c1)
        nm.createNotificationChannel(c2)
        nm.createNotificationChannel(c3)
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 102, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun serviceNotif(text: String): Notification =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("As-Shalah aktif")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openApp())
            .build()

    private fun lockIntent(req: Int, fill: Intent.() -> Unit): PendingIntent {
        val i = Intent(this, AlertActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        i.fill()
        return PendingIntent.getActivity(
            this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun postAlertNotif(kind: String, title: String, text: String) {
        try {
            val pi = lockIntent(110) {
                putExtra(AlertActivity.EX_KIND, kind)
                putExtra(AlertActivity.EX_TITLE, title)
                putExtra(AlertActivity.EX_SUB, text)
            }
            val stop = PendingIntent.getBroadcast(
                this, 111,
                Intent(this, AlarmReceiver::class.java).setAction(ACT_STOP_CALL),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(this, CH_ALERT)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .addAction(0, "Tutup", stop)
                .setDeleteIntent(stop)
                .build()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ALERT_ID, n)
        } catch (e: Exception) { }
    }

    /** Notifikasi HATI-HATI: menetap (tidak bisa digeser), muncul di layar kunci. */
    private fun postHatiNotif() {
        try {
            val pi = lockIntent(112) {
                putExtra(AlertActivity.EX_KIND, "h")
                putExtra(AlertActivity.EX_NAME, hatiName)
                putExtra(AlertActivity.EX_IQ, hatiIqMs)
            }
            val again = PendingIntent.getBroadcast(
                this, 113,
                Intent(this, AlarmReceiver::class.java).setAction(ACT_REPOST_HATI),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val mnt = Math.max(0L, (System.currentTimeMillis() - hatiIqMs) / 60000L)
            val n = NotificationCompat.Builder(this, CH_HATI)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("⚠️ HATI-HATI")
                .setContentText("Sholat $hatiName telah berlalu · $mnt menit sejak Iqomah. Ketuk lalu tahan 4 detik untuk menutup.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .setDeleteIntent(again)
                .build()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(HATI_ID, n)
        } catch (e: Exception) { }
    }
}
