package com.sholatku.app

import org.json.JSONObject
import java.util.Calendar
import java.util.GregorianCalendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

/** kind: "a" = azan, "i" = iqomah, "h" = hati-hati */
class Ev(
    val whenMs: Long,
    val kind: String,
    val key: String,
    val minute: Int,
    val ht: Int,
    val id: String
)

/** Port dari rumus di index.html (Kemenag: Fajar 20, Isya 18). */
object PrayerTimes {
    val KEYS = arrayOf("fajr", "dzuhur", "ashar", "maghrib", "isya")
    val NAMES = mapOf(
        "fajr" to "FAJR", "dzuhur" to "DZUHUR", "ashar" to "ASHAR",
        "maghrib" to "MAGHRIB", "isya" to "ISYA"
    )
    private val DL = intArrayOf(13, 15, 15, 12, 15)
    private val H0 = intArrayOf(11, 10, 10, 10, 15)
    private val RAD = Math.PI / 180.0

    fun fmt(m: Int): String {
        val x = ((m % 1440) + 1440) % 1440
        return String.format("%02d:%02d", x / 60, x % 60)
    }

    fun calc(y: Int, mo: Int, d: Int, lat: Double, lng: Double, tz: Double): IntArray {
        val u = GregorianCalendar(TimeZone.getTimeZone("UTC"))
        u.clear()
        u.set(y, mo, d, 12, 0, 0)
        val jd = u.timeInMillis / 86400000.0 + 2440587.5 - 2451545.0
        val g = (357.529 + 0.98560028 * jd) % 360
        val qq = (280.459 + 0.98564736 * jd) % 360
        val l = (qq + 1.915 * sin(g * RAD) + 0.02 * sin(2 * g * RAD)) % 360
        val e = 23.439 - 3.6e-7 * jd
        val ra = ((atan2(cos(e * RAD) * sin(l * RAD), cos(l * RAD)) / RAD / 15) % 24 + 24) % 24
        val dec = asin(sin(e * RAD) * sin(l * RAD)) / RAD
        var eq = qq / 15 - ra
        if (eq > 12) eq -= 24
        if (eq < -12) eq += 24
        val noon = 12 + tz - lng / 15 - eq

        fun h(a: Double): Double {
            val c = (sin(a * RAD) - sin(lat * RAD) * sin(dec * RAD)) / (cos(lat * RAD) * cos(dec * RAD))
            return acos(Math.max(-1.0, Math.min(1.0, c))) / RAD / 15
        }

        val aa = atan(1 / (1 + tan(abs(lat - dec) * RAD))) / RAD
        fun m(x: Double): Int = ceil(x * 60).toInt() + 2
        return intArrayOf(
            m(noon - h(-20.0)),
            m(noon),
            m(noon + h(aa)),
            m(noon + h(-0.833)),
            m(noon + h(-18.0))
        )
    }

    /** Semua kejadian (azan, iqomah, hati-hati) pada hari [day]. */
    fun events(cfg: JSONObject, day: Calendar): List<Ev> {
        val y = day.get(Calendar.YEAR)
        val mo = day.get(Calendar.MONTH)
        val d = day.get(Calendar.DAY_OF_MONTH)
        val start = day.clone() as Calendar
        start.set(Calendar.HOUR_OF_DAY, 0)
        start.set(Calendar.MINUTE, 0)
        start.set(Calendar.SECOND, 0)
        start.set(Calendar.MILLISECOND, 0)
        val base = start.timeInMillis
        val tz = TimeZone.getDefault().getOffset(base + 12 * 3600000L) / 3600000.0
        val lat = cfg.optDouble("lat", -5.1666665)
        val lng = cfg.optDouble("lng", 119.6666664)
        val t = calc(y, mo, d, lat, lng, tz)
        val manual = cfg.optString("src", "auto") == "manual"
        val tt = cfg.optJSONObject("t")
        val dayKey = "$y-$mo-$d-"
        val out = ArrayList<Ev>()
        for (i in KEYS.indices) {
            val k = KEYS[i]
            val o = tt?.optJSONObject(k)
            val az = if (manual && o != null && !o.isNull("az")) o.optInt("az") else t[i]
            val iq = if (manual && o != null && !o.isNull("iq")) o.optInt("iq") else az + DL[i]
            val ht = if (o != null && !o.isNull("ht")) o.optInt("ht") else H0[i]
            out.add(Ev(base + az * 60000L, "a", k, az, ht, dayKey + k + "a"))
            out.add(Ev(base + iq * 60000L, "i", k, iq, ht, dayKey + k + "i"))
            if (ht > 0) out.add(Ev(base + (iq + ht) * 60000L, "h", k, iq + ht, ht, dayKey + k + "h"))
        }
        return out
    }
}
