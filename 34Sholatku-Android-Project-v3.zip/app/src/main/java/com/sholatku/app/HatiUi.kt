package com.sholatku.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

/** Tampilan HATI-HATI (tahan 4 detik untuk menutup). Dipakai oleh overlay dan oleh layar kunci. */
object HatiUi {
    fun build(ctx: Context, h: Handler, name: String, iqMs: Long, onClose: () -> Unit): View {
        fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(dp(24), dp(24), dp(24), dp(24))
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0A1630"), Color.parseColor("#1F3A6E"))
        )

        val w = TextView(ctx)
        w.text = "⚠️"
        w.textSize = 60f
        w.gravity = Gravity.CENTER

        val title = TextView(ctx)
        title.text = "HATI-HATI"
        title.textSize = 44f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.parseColor("#E8B4A0"))
        title.gravity = Gravity.CENTER

        val m1 = TextView(ctx)
        m1.text = "🕌 Sholat $name telah berlalu"
        m1.textSize = 20f
        m1.typeface = Typeface.DEFAULT_BOLD
        m1.setTextColor(Color.WHITE)
        m1.gravity = Gravity.CENTER
        m1.setPadding(0, dp(12), 0, dp(8))

        val m2 = TextView(ctx)
        m2.textSize = 18f
        m2.setTextColor(Color.WHITE)
        m2.gravity = Gravity.CENTER

        val m3 = TextView(ctx)
        m3.textSize = 18f
        m3.setTextColor(Color.parseColor("#E8B4A0"))
        m3.gravity = Gravity.CENTER
        m3.setPadding(0, dp(4), 0, dp(36))

        val upd = object : Runnable {
            override fun run() {
                val now = System.currentTimeMillis()
                val c = Calendar.getInstance()
                m2.text = "🕐 Sekarang: " + String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
                val mnt = Math.max(0L, (now - iqMs) / 60000L)
                m3.text = "⏱️ Telah berlalu: $mnt menit sejak Iqomah"
                h.postDelayed(this, 5000)
            }
        }
        upd.run()

        val hold = TextView(ctx)
        hold.text = "TEKAN UNTUK TUTUP\n(Tahan 4 detik)"
        hold.textSize = 14f
        hold.typeface = Typeface.DEFAULT_BOLD
        hold.setTextColor(Color.WHITE)
        hold.gravity = Gravity.CENTER
        hold.setPadding(dp(24), dp(16), dp(24), dp(16))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#55FFFFFF"))
        bg.cornerRadius = dp(30).toFloat()
        hold.background = bg
        val closeRun = Runnable { onClose() }
        hold.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    hold.text = "TERUS TAHAN…"
                    h.postDelayed(closeRun, 4000)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    hold.text = "TEKAN UNTUK TUTUP\n(Tahan 4 detik)"
                    h.removeCallbacks(closeRun)
                }
            }
            true
        }

        root.addView(w)
        root.addView(title)
        root.addView(m1)
        root.addView(m2)
        root.addView(m3)
        root.addView(hold)

        val anim = ObjectAnimator.ofFloat(title, "alpha", 1f, 0.25f).apply {
            duration = 800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) {
                anim.cancel()
                h.removeCallbacks(upd)
                h.removeCallbacks(closeRun)
            }
        })
        return root
    }
}
