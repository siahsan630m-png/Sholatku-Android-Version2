package com.sholatku.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var geoOrigin: String? = null
    private var geoCb: GeolocationPermissions.Callback? = null
    private var askedOverlay = false

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val res = WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
        fileCb?.onReceiveValue(res)
        fileCb = null
    }

    private val geoLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        geoCb?.invoke(geoOrigin, granted, false)
        geoCb = null
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Tombol volume fisik HP mengatur volume azan/iqomah/hati² (stream alarm), tidak dikunci.
        volumeControlStream = android.media.AudioManager.STREAM_ALARM

        web = WebView(this)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.mediaPlaybackRequiresUserGesture = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                return try {
                    fileLauncher.launch(fileChooserParams!!.createIntent())
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                val ok = ContextCompat.checkSelfPermission(
                    this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                if (ok) {
                    callback?.invoke(origin, true, false)
                } else {
                    geoOrigin = origin
                    geoCb = callback
                    geoLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript(
                    "(function(){var b=document.querySelector('.v.on .bk');if(b){b.click();return 1}return 0})()"
                ) { r ->
                    if (r != "1") moveTaskToBack(true)
                }
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        startSvc(PrayerService.ACT_TICK)
    }

    override fun onResume() {
        super.onResume()
        startSvc(PrayerService.ACT_TICK)
        if (!askedOverlay && !Settings.canDrawOverlays(this)) {
            askedOverlay = true
            AlertDialog.Builder(this)
                .setTitle("Izin tampil di atas aplikasi lain")
                .setMessage(
                    "Agar tulisan dzikir, tombol − +, serta peringatan azan dan iqomah bisa " +
                        "mengambang di atas aplikasi lain, aktifkan izin “Tampil di atas aplikasi lain” untuk As-Shalah."
                )
                .setPositiveButton("Buka Pengaturan") { _, _ -> openOverlaySettings() }
                .setNegativeButton("Nanti", null)
                .show()
        } else if (Build.VERSION.SDK_INT >= 34 &&
            !(getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).canUseFullScreenIntent() &&
            !uiPrefs().getBoolean("asked_fsi", false)
        ) {
            uiPrefs().edit().putBoolean("asked_fsi", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Notifikasi di layar kunci")
                .setMessage(
                    "Agar azan, iqomah, dan HATI² muncul di layar kunci tanpa perlu membuka kunci, " +
                        "izinkan “Notifikasi layar penuh” untuk As-Shalah."
                )
                .setPositiveButton("Buka Pengaturan") { _, _ ->
                    try {
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
                        )
                    } catch (e: Exception) { }
                }
                .setNegativeButton("Nanti", null)
                .show()
        } else if (!isBatteryOk() && !uiPrefs().getBoolean("asked_batt", false)) {
            uiPrefs().edit().putBoolean("asked_batt", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Azan tetap bunyi di latar belakang")
                .setMessage(
                    "Agar azan tetap berbunyi saat aplikasi ditutup atau layar mati, izinkan As-Shalah " +
                        "berjalan tanpa pembatasan baterai."
                )
                .setPositiveButton("Izinkan") { _, _ -> askBattery() }
                .setNegativeButton("Nanti", null)
                .show()
        }
    }

    private fun uiPrefs() = getSharedPreferences("sholatku_ui", Context.MODE_PRIVATE)

    private fun isBatteryOk(): Boolean {
        return try {
            (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        } catch (e: Exception) {
            true
        }
    }

    @SuppressLint("BatteryLife")
    private fun askBattery() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
            }
        }
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun startSvc(action: String) {
        try {
            ContextCompat.startForegroundService(
                this, Intent(this, PrayerService::class.java).setAction(action)
            )
        } catch (e: Exception) {
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun sync(json: String) {
            if (Store.saveCfg(this@MainActivity, json)) PrayerService.instance?.onConfigChanged()
        }

        @JavascriptInterface
        fun getCount(): Int = Store.count(this@MainActivity)

        @JavascriptInterface
        fun batteryOk(): Boolean = this@MainActivity.isBatteryOk()

        @JavascriptInterface
        fun openBattery() {
            runOnUiThread { this@MainActivity.askBattery() }
        }

        @JavascriptInterface
        fun toggleDzikir(on: Boolean) {
            runOnUiThread {
                if (on) {
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        Toast.makeText(
                            this@MainActivity,
                            "Aktifkan izin “Tampil di atas aplikasi lain” untuk As-Shalah, lalu tekan tombol lagi.",
                            Toast.LENGTH_LONG
                        ).show()
                        openOverlaySettings()
                    } else {
                        startSvc(PrayerService.ACT_SHOW_DZ)
                    }
                } else {
                    startSvc(PrayerService.ACT_HIDE_DZ)
                }
            }
        }

        @JavascriptInterface
        fun test(kind: String, json: String) {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(
                        this@MainActivity,
                        "Izin “Tampil di atas aplikasi lain” belum aktif, tampilan mengambang tidak muncul.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                val svc = PrayerService.instance
                if (svc != null) svc.runTest(kind, json) else startSvc(PrayerService.ACT_TICK)
            }
        }

        @JavascriptInterface
        fun saveAudio(id: String, b64: String) {
            if (!Regex("[A-Za-z0-9_-]+").matches(id)) return
            try {
                val dir = File(filesDir, "audio")
                dir.mkdirs()
                File(dir, id).writeBytes(Base64.decode(b64, Base64.DEFAULT))
            } catch (e: Exception) {
            }
        }
    }
}
