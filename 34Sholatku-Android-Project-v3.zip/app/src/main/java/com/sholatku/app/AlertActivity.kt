package com.sholatku.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Tampil di atas layar kunci (tanpa buka kunci) untuk azan, iqomah, dan HATI-HATI. */
class AlertActivity : Activity() {
    companion object {
        const val EX_KIND = "kind"      // "a" | "i" | "h"
        const val EX_TITLE = "title"
        const val EX_SUB = "sub"
        const val EX_NAME = "name"
        const val EX_IQ = "iq"
        @Volatile var current: AlertActivity? = null
    }

    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        render()
    }

    override fun onNewIntent(intent: android.content.Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun render() {
        val kind = intent?.getStringExtra(EX_KIND) ?: "a"
        if (kind == "h") {
            val name = intent?.getStringExtra(EX_NAME) ?: ""
            val iq = intent?.getLongExtra(EX_IQ, System.currentTimeMillis()) ?: System.currentTimeMillis()
            setContentView(HatiUi.build(this, h, name, iq) {
                val svc = PrayerService.instance
                if (svc != null) svc.closeHati() else finish()
            })
        } else {
            setContentView(callView(kind))
        }
    }

    private fun callView(kind: String): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(dp(28), dp(28), dp(28), dp(28))
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0A1630"), Color.parseColor("#1F3A6E"))
        )
        val ic = TextView(this)
        ic.text = "🔔"
        ic.textSize = 44f
        ic.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(Color.parseColor(if (kind == "i") "#30A46C" else "#E5484D"))
        ic.background = g
        ic.layoutParams = LinearLayout.LayoutParams(dp(96), dp(96))
        val t1 = TextView(this)
        t1.text = intent?.getStringExtra(EX_TITLE) ?: ""
        t1.textSize = 28f
        t1.typeface = Typeface.DEFAULT_BOLD
        t1.setTextColor(Color.WHITE)
        t1.gravity = Gravity.CENTER
        t1.setPadding(0, dp(20), 0, dp(6))
        val t2 = TextView(this)
        t2.text = intent?.getStringExtra(EX_SUB) ?: ""
        t2.textSize = 18f
        t2.setTextColor(Color.parseColor("#B8C4DA"))
        t2.gravity = Gravity.CENTER
        t2.setPadding(0, 0, 0, dp(32))
        val close = TextView(this)
        close.text = "TUTUP"
        close.textSize = 16f
        close.typeface = Typeface.DEFAULT_BOLD
        close.setTextColor(Color.WHITE)
        close.gravity = Gravity.CENTER
        close.setPadding(dp(40), dp(14), dp(40), dp(14))
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#3A4F7A"))
        bg.cornerRadius = dp(30).toFloat()
        close.background = bg
        close.setOnClickListener {
            PrayerService.instance?.stopCall()
            finish()
        }
        root.addView(ic)
        root.addView(t1)
        root.addView(t2)
        root.addView(close)
        return root
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }
}
